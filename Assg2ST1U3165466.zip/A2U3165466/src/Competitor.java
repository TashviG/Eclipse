//author: Tashvi Gooroochurn
//u3165466
//ques2
//date: 16/12/16
//using constructors


public class Competitor {

String name,event;
String ID;
double performance;

 public Competitor()
 {
	 this.name="";
	 this.ID="";
	 this.event="";
	 this.performance=0.0;

	 

	}

 public Competitor(String name, String event, double performance, String ID)
 {
	 this.name=name;
	 this.ID=ID;
	 this.event=event;
	 this.performance=performance;
	  
 }
 
 public void setname(String name)
 {
	 this.name = name;
 }
 
 public void setID(String ID)
 {
	 this.ID = ID;
 }
 public void setevent(String event)
 {
	 this.event = event;
 }
 public void setperformance(double performance)
 {
	 this.performance = performance;
 }
 
 public String getname()
 {
	 return name;
 }
 public String getID()
 {
	 return ID;
 }
 public String getevent()
 {
	 return event;
	
 }
 
 public double getperformance()
 {
	 return performance;
 }
 public String toString()
 {
	 return name + " " + event + " " + Double.toString(performance) + " " + ID;
  }
 
}
