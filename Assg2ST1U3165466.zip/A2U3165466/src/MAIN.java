//author: Tashvi Gooroochurn
//u3165466
//ques2
//date: 16/12/16
//MAIN
//This is the main class linked to the CompetitorGui

import java.awt.EventQueue;

public class MAIN
{
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CompetitorGui window = new CompetitorGui();  // creating the object of CompetitorGui and calling the constructor
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
