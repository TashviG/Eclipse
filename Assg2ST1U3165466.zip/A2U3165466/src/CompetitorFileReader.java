//author: Tashvi Gooroochurn
//u3165466
//ques2
//date: 16/12/16
//Competitor File reader
//This class reads the file Competitors.txt

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CompetitorFileReader {

//creating an array	
private Competitor[] CompetitorArray = new Competitor [20];

public CompetitorFileReader()//constructor for reading file
{
int j=0;
String fileName = "competitors.txt"; 
for(int i=0;i<20;i++){
CompetitorArray[i] = new Competitor();
}


try
{
Scanner inputStream = new Scanner(new File(fileName)); 
while (inputStream.hasNextLine())// Read the rest of the file line by line
{

try{
String line = inputStream.nextLine();
String[] ary = line.split(","); //separated by comma

//changing to string
this.CompetitorArray[j] = new Competitor(ary[0],ary[1],Double.parseDouble(ary[2]),ary[3]);
j++;


}
catch(java.lang.NumberFormatException e)
{	
System.out.println("Invalid input from file"); 
}

}
inputStream.close( ); 
}

catch(FileNotFoundException e)
{
System.out.println("Cannot find file " + fileName);}
} 

//getting the first item in the file
public String getname(int i)
{
return CompetitorArray[i].getname();
}

//getting the second item in the list
public String getID(int i)
{
return CompetitorArray[i].getID();
}

//getting the third item in the list
public String getevent(int i)
{
return CompetitorArray[i].getevent();
}

//getting the fourth item in the list
public String getperformance(int i)
{
return Double.toString(CompetitorArray[i].getperformance());

}

public Competitor getCompetitor(int i){
return CompetitorArray[i];
}


}
