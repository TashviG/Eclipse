//author: Tashvi Gooroochurn
//u3165466
//Ques1
//date: 16/12/16
//Write	a	Java	Console	or	GUI	based	application	program	that	reads	the	CSV	file	and	calculates	the	average	number	of	positive
//axillary	nodes	detected	for	patients	that	survived	5	years	or	longer,	and	the	average	number	of	positive	axillary	
//nodes	detected	for	patients	that	died	within	5	years.		A	significant	difference	between	the	two	averages	suggests	
//whether	or	not	the	number	of	positive	axillary	nodes	detected	can	be	used	to	predict	survival	time.		
//Your	program	should	ignore	the	age	and	year	fields	for	each	record.	
	
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;

public class InputOutputEx {

    public static void main(String[] args) {
    	
    	//declaring the variables
        double average;
        String csvFile = "haberman.data.txt";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        String [] array = null;
        double sum=0;
        int count=0;
        int sumwithin5=0;
        int countwithin5=0;
        double avgwithin5=0.0;
        double avg=0.0;
       
       
        try {
           //reads the file
            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                  array = line.split(cvsSplitBy);

               // System.out.println("status: " + array[3] + " , axillarynodes: " + array[2]);
          
               //int se = 1; 
               
              //if last column = 1, i.e status=1
               if(Integer.parseInt(array[3])==1){
             
               {
            	 sum+=Integer.parseInt(array[2]); 
            	 count++;
            	 
            	 avg = (sum/count);
               }
                
                
               }
               //if status=2
               else 
               {
            	   
            	   {
            	   sumwithin5+=Integer.parseInt(array[2]); 
              	 countwithin5++; 
              	avgwithin5 = (sumwithin5/countwithin5);
               }
               
            
               }  
            
            
            }
            
            
            
            		
        }catch (FileNotFoundException e) {  //catches exception
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
               
                DecimalFormat df= new DecimalFormat("####0.00");	
              //prints the average if the patient survived 5 years or longer
                System.out.println("The average of the patients who survived 5 years or longer: " +df.format(avg));
                
              //prints the average if the patient died within 5 years.
                System.out.println("The average of the patients who died within 5 years: " +df.format(avgwithin5));
            }
        }
    }
}

	


