//author: Tashvi Gooroochurn
//u3165466
//ques2
//date: 16/12/16
//Gui
//This is the Competitor Gui where the user can get all the information needed such as ID,name,performance record and pictures when it is run.

import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionListener;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;

import java.awt.Panel;

import javax.swing.AbstractAction;
import javax.swing.Action;

public class CompetitorGui {

int index=0;

 	
public JFrame frame;
@SuppressWarnings("rawtypes")
ListModel listname = new DefaultListModel();


private String[] listTFString = new String[20];
//private final Action action = new SwingAction();

/**
* Launch the application.
*/


/**
* Create the application.
*/
public CompetitorGui() {

CompetitorList CompetitorList = new CompetitorList();


//creates text for description text field
for(int i=0;i<20;i++){
listTFString[i] = "Name: " + CompetitorList.getNthname(i) +'\n'+
"ID: " + CompetitorList.getNthID(i) +'\n'+
"Event : " + CompetitorList.getNthevent(i)+'\n'+
"Performance: " + CompetitorList.getNthperformance(i);


((DefaultListModel) listname).addElement(CompetitorList.getNthname(i)); // Creating the Listmodel for Jlist

}

initialize();

}

/**
* Initialize the contents of the frame.
*/
private void initialize() {
frame = new JFrame();
frame.setBounds(100, 100, 970, 644);
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.getContentPane().setLayout(null);

JList<String> Competitorlist = new JList();
Competitorlist.setBounds(61, 100, 148, 306);
frame.getContentPane().add(Competitorlist);

Competitorlist.setModel(listname); // Setting the list model values to Jlist

JTextArea Competitordetails = new JTextArea();
Competitordetails.setBounds(270, 100, 177, 190);
frame.getContentPane().add(Competitordetails);

JButton GetDetailsBTN = new JButton("Get Details");

GetDetailsBTN.setBounds(43, 498, 207, 50);
frame.getContentPane().add(GetDetailsBTN);

JLabel lblCompetitorName = new JLabel("Competitor's Name");
lblCompetitorName.setBounds(61, 49, 158, 35);
frame.getContentPane().add(lblCompetitorName);

JLabel lblDetails = new JLabel("Details");
lblDetails.setBounds(270, 58, 158, 29);
frame.getContentPane().add(lblDetails);
JButton btnExit = new JButton("Exit");
btnExit.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent arg0) {
		System.exit(0);
	}
});

btnExit.setBounds(318, 498, 207, 50);
frame.getContentPane().add(btnExit);
Panel JPanel = new Panel();
JPanel.setBounds(656, 100, 229, 306);
frame.getContentPane().add(JPanel);
//JPanel.add(new JLabel(new ImageIcon("image.jpg")));

JPanel.setVisible(false);

GetDetailsBTN.addActionListener(new ActionListener() {
	JLabel label = new JLabel();
	

public void actionPerformed(ActionEvent e) {
	index = Competitorlist.getSelectedIndex();
    label.setOpaque(true);

	
try{
if(Competitorlist.getSelectedIndex()>-1) {
Competitordetails.setText(listTFString[Competitorlist.getSelectedIndex()]);
}

//when the first item in a list is selected display "Mary.jpg"
if(index == 0){
	 
	ImageIcon icon = new ImageIcon("Mary.jpg"); 
	
	label.setIcon(icon); 
	JPanel.add(label); 
	//System.out.print("selected index: " + index);

}

//when the second item in a list is selected display "Melinda.jpg"
else if(index == 1){
	ImageIcon icon = new ImageIcon("Melinda.jpg"); 

	label.setIcon(icon); 
	JPanel.add(label); 
	//System.out.print("selected index: " + index);
}

//when the third item in a list is selected display "Hong.jpg"
else if(index == 2){
	ImageIcon icon = new ImageIcon("Hong.jpg"); 

	label.setIcon(icon); 
	JPanel.add(label); 
	//System.out.print("selected index: " + index);
	
}

//when the fourth item in a list is selected display "Ahmed.jpg"
if(index == 3){
	ImageIcon icon = new ImageIcon("Ahmed.jpg"); 

	label.setIcon(icon); 
	JPanel.add(label); 
	//System.out.print("selected index: " + index);
}

//when the fifth item in a list is selected display "Bill.jpg"
if(index == 4){
	ImageIcon icon = new ImageIcon("Bill.jpg"); 

	label.setIcon(icon); 
	JPanel.add(label); 
	//System.out.print("selected index: " + index);
}

//when the sixth item in a list is selected display "Rohan.jpg"
if(index == 5){
	ImageIcon icon = new ImageIcon("Rohan.jpg"); 

	label.setIcon(icon); 
	JPanel.add(label); 
	//System.out.print("selected index: " + index);
}

//when the seventh item in a list is selected display "Peter.jpg"
if(index == 6){
	ImageIcon icon = new ImageIcon("Peter.jpg"); 

	label.setIcon(icon); 
	JPanel.add(label); 
	//System.out.print("selected index: " + index);
}

JPanel.setVisible(true);
}

catch(NullPointerException e1){
System.out.println("Null point excpetion" );
}



}

private ListSelectionListener JPanel(JLabel jLabel) {
	// TODO Auto-generated method stub
	return null;
}

});
}
}



