//author: Tashvi Gooroochurn
//u3165466
//ques2
//date: 16/12/16
//Competitor List
//This class is linked to the competitor file reader and returns the items in a list.

import javax.swing.event.ListSelectionListener;

public class CompetitorList {

        //declaring an array
        String[][] list = new String[4][20];
        
        public CompetitorList()
        {
            CompetitorFileReader object1= new CompetitorFileReader();
            
            for(int i=0;i<20;i++)
            {
            this.list[0][i] = object1.getname(i);
            this.list[1][i] = object1.getID(i);
            this.list[2][i] = object1.getevent(i);
            this.list[3][i] = object1.getperformance(i);
            }
        
        }
        
        
         public String getNthString(int n){
            return list[0][n] + list[1][n] + list[2][n] + list[3][n];
        }
        
        public String getNthname(int n){
            return list[0][n];
        }
     
        public String getNthID(int n){
            return list[1][n];
        }

        public String getNthevent(int n){
            return list[2][n];
        }
    
        public String getNthperformance(int n){
            return list[3][n];
        }

}
		